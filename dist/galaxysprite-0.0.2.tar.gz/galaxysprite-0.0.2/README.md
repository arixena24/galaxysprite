# galaxysprite

This package takes in any data type and turns it into a movie. Currently, we have used it with simulated galaxy data. 

Function that are written: 

stack function takes in the data given and returns every given N number of plots

DEC_RA function cuts out a slice of an object given a particular dec and ra


Functions that are needed: 

function that plots the mass density as a function of radius 

Evolution class: 
function that can input the coordinates and gives out a list of Dark Matter regions of the galaxy based on the coords
function that can show the SFR 
dark matter evolution 
steller evoltion 

function that plots the galaxy's state with evolution of redshift 

![Code/Astro](https://img.shields.io/badge/Code_Astro-purple)

[![DOI](https://zenodo.org/badge/DOI/10.5281/zenodo.8145254.svg)](https://doi.org/10.5281/zenodo.8145254)
